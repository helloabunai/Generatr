from generatr import main
main()